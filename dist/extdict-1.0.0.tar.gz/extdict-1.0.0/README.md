# Extended Dictionary Package

This Python package that defines the `Table` class, which represents a table with content, read-only indices, and size constraints. It provides various methods and properties to manage a table with content, enforce size limits, and support operations such as adding, removing, and retrieving items.

## Features

- **Table Class**: A class to represent and manage tables with content and size constraints.
- **Size Constraints**: Supports properties for setting minimum and maximum size limits.
- **Content Management**: Provides methods for adding and removing items.
- **Read-Only Indices**: Manages indices in a read-only manner.

## Installation

To install this package, simply use `pip`:

```bash
pip install extdict
```
